<script setup>

</script>

<template>
<span>测试</span>
</template>

<style scoped>

</style>