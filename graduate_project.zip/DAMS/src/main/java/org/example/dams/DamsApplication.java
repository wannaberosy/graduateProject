package org.example.dams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DamsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DamsApplication.class, args);
    }

}
