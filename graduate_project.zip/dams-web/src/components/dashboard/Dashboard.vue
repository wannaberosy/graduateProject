<template>
  <div class="dashboard-container">
    <!-- 顶部统计卡片 -->
    <el-row :gutter="20" class="stats-cards">
      <el-col :span="6" v-for="(stat, index) in stats" :key="index">
        <el-card shadow="hover">
          <div class="stat-card">
            <div class="stat-icon">
              <i :class="stat.icon"></i>
            </div>
            <div class="stat-info">
              <div class="stat-title">{{ stat.title }}</div>
              <div class="stat-number">{{ stat.value }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 图表区域 -->
    <el-row :gutter="20" class="chart-row">
      <el-col :span="24">
        <el-card class="chart-card">
          <div slot="header">
            <span>出入库趋势</span>
          </div>
          <div class="chart-container">
            <div ref="trendChart" style="height: 300px"></div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 最近操作记录 -->
    <el-row>
      <el-col :span="24">
        <el-card class="activity-card">
          <div slot="header">
            <span>最近操作记录</span>
          </div>
          <el-timeline>
            <el-timeline-item
              v-for="(activity, index) in recentActivities"
              :key="index"
              :type="activity.action === '1' ? 'success' : 'danger'"
              :timestamp="activity.createtime"
            >
              <span class="activity-content">
                {{ activity.username }}
                <span :class="{'in-action': activity.action === '1', 'out-action': activity.action === '2'}">
                  {{ activity.action === '1' ? '入库' : '出库' }}
                </span>
                {{ activity.goodsname }}
                <span class="count-text">
                  {{ Math.abs(activity.count) }}个
                </span>
              </span>
            </el-timeline-item>
          </el-timeline>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import * as echarts from 'echarts'

export default {
  name: 'Dashboard',
  data() {
    return {
      stats: [
        { title: '仓库总数', value: 0, icon: 'el-icon-house' },
        { title: '商品总数', value: 0, icon: 'el-icon-goods' },
        { title: '今日入库', value: 0, icon: 'el-icon-top' },
        { title: '今日出库', value: 0, icon: 'el-icon-bottom' }
      ],
      trendChart: null,
      recentActivities: []
    }
  },
  methods: {
    async loadData() {
      await this.loadOverview()
      await this.loadRecentActivities()
      await this.loadTrend()
    },
    
    async loadOverview() {
      try {
        const res = await this.$axios.get(this.$httpUrl + '/dashboard/overview')
        if (res.data.code === 200) {
          const data = res.data.data
          this.stats[0].value = data.storageCount
          this.stats[1].value = data.goodsCount
          this.stats[2].value = data.todayIn
          this.stats[3].value = data.todayOut
        }
      } catch (error) {
        console.error('加载总览数据失败:', error)
      }
    },

    async loadRecentActivities() {
      try {
        const res = await this.$axios.get(this.$httpUrl + '/dashboard/recent-activities')
        if (res.data.code === 200) {
          // 处理每条记录
          this.recentActivities = res.data.data.map(item => ({
            ...item,
            // 确保 action 是字符串类型
            action: String(item.action),
            // 确保数量为正数显示
            count: Math.abs(Number(item.count))
          }));
          console.log('处理后的活动记录:', this.recentActivities); // 调试日志
        }
      } catch (error) {
        console.error('加载最近活动失败:', error)
        this.$message.error('加载最近活动失败: ' + error.message)
      }
    },

    async loadTrend() {
      try {
        const res = await this.$axios.get(this.$httpUrl + '/dashboard/inout-trend')
        if (res.data.code === 200) {
          const data = res.data.data
          this.initTrendChart(data)
        }
      } catch (error) {
        console.error('加载趋势数据失败:', error)
      }
    },

    initTrendChart(data) {
      if (!this.trendChart) {
        this.trendChart = echarts.init(this.$refs.trendChart)
      }
      
      this.trendChart.setOption({
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['入库', '出库']
        },
        xAxis: {
          type: 'category',
          data: data.dates
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '入库',
            type: 'line',
            data: data.in
          },
          {
            name: '出库',
            type: 'line',
            data: data.out
          }
        ]
      })
    },

    handleResize() {
      if (this.trendChart) {
        this.trendChart.resize()
      }
    }
  },
  
  mounted() {
    this.loadData()
    window.addEventListener('resize', this.handleResize)
  },
  
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize)
    if (this.trendChart) {
      this.trendChart.dispose()
    }
  }
}
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}

.stats-cards {
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
}

.stat-icon {
  font-size: 48px;
  margin-right: 20px;
  color: #409EFF;
}

.stat-info {
  flex-grow: 1;
}

.stat-title {
  font-size: 14px;
  color: #909399;
}

.stat-number {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
}

.chart-row {
  margin-bottom: 20px;
}

.chart-card {
  margin-bottom: 20px;
}

.chart-container {
  height: 300px;
}

.activity-card {
  height: 400px;
  overflow-y: auto;
}

.activity-content {
  display: flex;
  align-items: center;
  gap: 8px;
}

.in-action {
  color: #67C23A;
  font-weight: bold;
  padding: 2px 6px;
  border-radius: 4px;
  background-color: #f0f9eb;
}

.out-action {
  color: #F56C6C;
  font-weight: bold;
  padding: 2px 6px;
  border-radius: 4px;
  background-color: #fef0f0;
}

.count-text {
  font-weight: bold;
  color: #606266;
}

.el-timeline-item {
  padding-bottom: 20px;
}

.el-timeline-item:last-child {
  padding-bottom: 0;
}

.el-timeline-item__timestamp {
  font-size: 13px;
  color: #909399;
}
</style> 