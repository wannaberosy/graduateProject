package org.example.dams.service;

import org.example.dams.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zqy
 * @since 2025-04-10
 */
public interface MenuService extends IService<Menu> {

}
