package org.example.dams.mapper;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.example.dams.entity.Goods;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.example.dams.entity.Goodstype;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author zqy
 * @since 2025-04-11
 */
@Mapper
public interface GoodsMapper extends BaseMapper<Goods> {
    IPage pageCC(IPage<Goods> page, @Param(Constants.WRAPPER) Wrapper wrapper);

     @Select("SELECT g.*, s.name as storage_name, gt.name as type_name " +
            "FROM goods g " +
            "LEFT JOIN storage s ON g.storage = s.id " +
            "LEFT JOIN goodstype gt ON g.goodstype = gt.id " +
            "${ew.customSqlSegment}")
     List<Goods> selectWarningGoods(@Param("ew") QueryWrapper<Goods> queryWrapper);
    
    /**
     * 查询商品分类分布
     */
    @Select("SELECT gt.name, COUNT(g.id) as count, SUM(g.count) as total_count " +
            "FROM goodstype gt " +
            "LEFT JOIN goods g ON gt.id = g.goodstype " +
            "GROUP BY gt.id, gt.name")
    List<Map<String, Object>> selectTypeDistribution();
}
